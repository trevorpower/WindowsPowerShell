function global:Restore-Database($branch = "git1601") {
        Try
        {
            pushd "$env:GX_HOME\$branch"
            .\Scripts\RestoreDbBackup.ps1
        }
        Finally
        {
            popd
        }
    }

function global:Install-NpmDependencies($branch = "git1601") {
    Try
    {
        pushd "$env:GX_HOME\$branch\KneatGxApplication\Kneat.Gx.Web.App"
        npm install
    }
    Finally
    {
        popd
    }
}

function global:TFS-Command($task, $branch = "git1601") {
    Try
    {
        pushd "$env:GX_HOME\$branch"
        tf $task
    }
    Finally
    {
        popd
    }
}

function global:Build-App($task, $branch = "git1601") {
    Try
    {
        pushd "$env:GX_HOME\$branch"
        if($task) {
            msbuild .\Kneat.Gx.sln /p:Configuration=Debug /t:$task
        } else {
            msbuild .\Kneat.Gx.sln /p:Configuration=Debug
        }
    }
    Finally
    {
        Notify-Custom "Build Notification" "Build Finished successfully"
        popd
    }
}

function global:Run-WebAppGulp($task, $branch = "git1601"){
    Try
    {
        pushd "$env:GX_HOME\$branch\KneatGxApplication\Kneat.Gx.Web.App"
        
        if (-Not $task) {
            gulp    
        } else {
            gulp $task
        }
    }
    Finally
    {
        popd
    }
}


function global:FixMyBuild($branch = "git1601"){
    kbuild $branch; kinst $branch; kulp $branch build; kulp $branch JSX;
}

function global:WebAppConsole() {
    cd $env:GX_HOME"\git1601"
    cc
    powershell -new_console:sH
    cd $env:GX_HOME"\git1601\KneatGxApplication\Kneat.Gx.Web.App"
    cc
}

function global:Search-WorkItem($Search = "") {
        
   Add-Type -AssemblyName System.Web

   $encodedSearch = [System.Web.HttpUtility]::UrlEncode($Search)

   if($Search | isNumeric) {
      Start-Process "http://srv-tfs2013:8080/tfs/DefaultCollection/git1601/_workitems#_a=edit&id=$encodedSearch"
      return   
   }
    
   Start-Process "http://srv-tfs2013:8080/tfs/DefaultCollection/git1601/_workItems#searchText=$encodedSearch&_a=search"
}

filter isNumeric() {
    return $_ -is [byte]  -or $_ -is [int16]  -or $_ -is [int32]  -or $_ -is [int64]  `
       -or $_ -is [sbyte] -or $_ -is [uint16] -or $_ -is [uint32] -or $_ -is [uint64] `
       -or $_ -is [float] -or $_ -is [double] -or $_ -is [decimal]
}

function global:GxPullRequests() {
    Add-Type -AssemblyName System.Web
    Start-Process "http://srv-tfs2013:8080/tfs/DefaultCollection/_git/git1601/pullrequests#filter=3&_a=active"
}

function global:LoadVmPullRequests() {
    Add-Type -AssemblyName System.Web
    Start-Process "https://kneatsolutions.visualstudio.com/DefaultCollection/CD/_git/load_vm/pullrequests"
}

function global:OpenLink($link) {
    Add-Type -AssemblyName System.Web
    Start-Process $link
}
# function global:K-Env($key, $value) {
#     if(-not $value) {
#         echo $env:$key
#     } else {
#         [Environment]::SetEnvironmentVariable( $key, $env:"${key}", [System.EnvironmentVariableTarget]::Machine )
#     }
# }

function global:Notify-Custom($Title, $Message, $Duration = 10000, $MessageType = "Info") {

    [system.Reflection.Assembly]::LoadWithPartialNsame('System.Windows.Forms') | Out-Null            
    $balloon = New-Object System.Windows.Forms.NotifyIcon            
    $path = Get-Process -id $pid | Select-Object -ExpandProperty Path            
    $icon = [System.Drawing.Icon]::ExtractAssociatedIcon($path)            
    $balloon.Icon = $icon            
    $balloon.BalloonTipIcon = $MessageType            
    $balloon.BalloonTipText = $Message            
    $balloon.BalloonTipTitle = $Title            
    $balloon.Visible = $true            
    $balloon.ShowBalloonTip($Duration)   
}


filter isNumeric() {
    return $_ -is [byte]  -or $_ -is [int16]  -or $_ -is [int32]  -or $_ -is [int64]  `
       -or $_ -is [sbyte] -or $_ -is [uint16] -or $_ -is [uint32] -or $_ -is [uint64] `
       -or $_ -is [float] -or $_ -is [double] -or $_ -is [decimal]
}

function RestartVs() {
   $
   Stop-ProcessByName devenv; ii *.sln;
}

function Run-DataGen() {
   ii "$env:GX_HOME\git1601\Kneat.Gx.Db.DataGeneration\bin\Debug\Kneat.Gx.Db.DataGeneration.exe";
}

function Use-DocsGenerator() {
   gulp docs --gulpfile $env:GX_HOME\git1601\gulpfile.js 
   gulp develop --gulpfile $env:DEV_PORTAL_HOME\gulpfile.js
}


Set-Alias rvs RestartVs
Set-Alias gendevdocs Use-DocsGenerator
Set-Alias kinst Install-NpmDependencies
Set-Alias kulp Run-WebAppGulp
Set-Alias kdb Restore-Database
Set-Alias ktf TFS-Command
Set-Alias kbuild Build-App
# Set-Alias kenv K-Env

Set-Alias fmb Fix-MyBuild
Set-Alias wac WebAppConsole
Set-Alias swi Search-WorkItem
Set-Alias gxprs GxPullRequests
Set-Alias loadvmprs LoadVmPullRequests
Set-LocationAlias kapp $env:GX_HOME"\git1601"
Set-LocationAlias loadvm "E:\\Workspace\\Gx\\Load_VM"
Set-LocationAlias load "E:\\Workspace\\Gx\\Load"

Export-ModuleMember -Alias * -Function *